<?php
return [
    'site_name' => 'Соц сеть 1',
];
?>
